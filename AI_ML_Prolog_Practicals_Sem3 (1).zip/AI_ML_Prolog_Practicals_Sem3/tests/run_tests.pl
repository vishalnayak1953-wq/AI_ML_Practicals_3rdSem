% Run from any working directory with:
%   swipl -q -s tests/run_tests.pl
% This file loads each practical and checks representative behavior.

:- use_module(library(plunit)).

:- prolog_load_context(directory, TestDir),
   atom_concat(TestDir, '/../unit_1_introduction_to_ai/practical_01_knowledge_base.pl', P01),
   load_files(P01, [if(not_loaded)]).
:- prolog_load_context(directory, TestDir),
   atom_concat(TestDir, '/../unit_1_introduction_to_ai/practical_02_arithmetic_factorial_fibonacci.pl', P02),
   load_files(P02, [if(not_loaded)]).
:- prolog_load_context(directory, TestDir),
   atom_concat(TestDir, '/../unit_1_introduction_to_ai/practical_03_list_operations.pl', P03),
   load_files(P03, [if(not_loaded)]).
:- prolog_load_context(directory, TestDir),
   atom_concat(TestDir, '/../unit_1_introduction_to_ai/practical_04_college_timetable.pl', P04),
   load_files(P04, [if(not_loaded)]).
:- prolog_load_context(directory, TestDir),
   atom_concat(TestDir, '/../unit_1_introduction_to_ai/practical_05_student_classification.pl', P05),
   load_files(P05, [if(not_loaded)]).
:- prolog_load_context(directory, TestDir),
   atom_concat(TestDir, '/../unit_2_problem_solving_and_search/practical_06_breadth_first_search.pl', P06),
   load_files(P06, [if(not_loaded)]).
:- prolog_load_context(directory, TestDir),
   atom_concat(TestDir, '/../unit_2_problem_solving_and_search/practical_07_greedy_best_first_search.pl', P07),
   load_files(P07, [if(not_loaded)]).
:- prolog_load_context(directory, TestDir),
   atom_concat(TestDir, '/../unit_2_problem_solving_and_search/practical_08_a_star_search.pl', P08),
   load_files(P08, [if(not_loaded)]).
:- prolog_load_context(directory, TestDir),
   atom_concat(TestDir, '/../unit_2_problem_solving_and_search/practical_09_hill_climbing.pl', P09),
   load_files(P09, [if(not_loaded)]).
:- prolog_load_context(directory, TestDir),
   atom_concat(TestDir, '/../unit_2_problem_solving_and_search/practical_10_simulated_annealing.pl', P10),
   load_files(P10, [if(not_loaded)]).
:- prolog_load_context(directory, TestDir),
   atom_concat(TestDir, '/../unit_2_problem_solving_and_search/practical_11_map_coloring_csp.pl', P11),
   load_files(P11, [if(not_loaded)]).
:- prolog_load_context(directory, TestDir),
   atom_concat(TestDir, '/../unit_2_problem_solving_and_search/practical_12_n_queens.pl', P12),
   load_files(P12, [if(not_loaded)]).

:- begin_tests(practical_01_knowledge_base).
test(student_course_fact_and_rule) :- user:student_course(vishal, artificial_intelligence).
test(course_student_list) :-
    user:students_in_course(artificial_intelligence, Students),
    sort(Students, [neha, riya, vishal]).
test(course_mate) :- user:course_mates(vishal, riya).
:- end_tests(practical_01_knowledge_base).

:- begin_tests(practical_02_arithmetic_factorial_fibonacci).
test(arithmetic) :-
    user:add_numbers(12, 8, 20),
    user:subtract_numbers(12, 8, 4),
    user:multiply_numbers(12, 8, 96),
    user:divide_numbers(12, 3, Quotient),
    Quotient =:= 4.
test(factorial) :- user:factorial(5, 120).
test(fibonacci) :- user:fibonacci(7, 13).
test(fibonacci_series) :- user:fibonacci_series(8, [0,1,1,2,3,5,8,13]).
test(divide_by_zero, [fail]) :- user:divide_numbers(12, 0, _).
:- end_tests(practical_02_arithmetic_factorial_fibonacci).

:- begin_tests(practical_03_list_operations).
test(append) :- user:my_append([a,b], [c,d], [a,b,c,d]).
test(reverse) :- user:my_reverse([1,2,3,4], [4,3,2,1]).
test(member_found) :- user:member_of(blue, [red,blue,green]).
test(member_missing, [fail]) :- user:member_of(black, [red,blue,green]).
test(length) :- user:my_list_length([p,q,r,s], 4).
:- end_tests(practical_03_list_operations).

:- begin_tests(practical_04_college_timetable).
test(faculty_has_three_classes) :-
    user:faculty_classes(dr_sharma, Classes),
    length(Classes, 3).
test(subject_timetable) :-
    user:subject_timetable(artificial_intelligence, Entries),
    length(Entries, 3).
test(room_schedule) :-
    user:room_schedule(room_101, Entries),
    length(Entries, 3).
:- end_tests(practical_04_college_timetable).

:- begin_tests(practical_05_student_classification).
test(topper) :- user:student_result(riya, topper).
test(average) :- user:student_result(kabir, average).
test(fail) :- user:student_result(neha, fail).
test(percentage) :- user:percentage(riya, Percentage), Percentage > 90.
:- end_tests(practical_05_student_classification).

:- begin_tests(practical_06_breadth_first_search).
test(finds_shortest_path) :-
    user:bfs_path(s, g, Path),
    Path = [s|_],
    last(Path, g),
    length(Path, 4).
test(start_is_goal) :- user:bfs_path(s, s, [s]).
:- end_tests(practical_06_breadth_first_search).

:- begin_tests(practical_07_greedy_best_first_search).
test(finds_a_path) :-
    user:greedy_best_first(s, g, Path),
    Path = [s|_],
    last(Path, g).
test(start_is_goal) :- user:greedy_best_first(s, s, [s]).
:- end_tests(practical_07_greedy_best_first_search).

:- begin_tests(practical_08_a_star_search).
test(finds_optimal_cost) :-
    user:a_star(s, g, Path, Cost),
    Path = [s|_],
    last(Path, g),
    Cost =:= 5.
test(start_is_goal) :- user:a_star(s, s, [s], 0).
:- end_tests(practical_08_a_star_search).

:- begin_tests(practical_09_hill_climbing).
test(reaches_peak) :- user:hill_climb(0, 5, 25).
test(starts_at_peak) :- user:hill_climb(5, 5, 25).
:- end_tests(practical_09_hill_climbing).

:- begin_tests(practical_10_simulated_annealing).
test(valid_result) :-
    user:simulated_annealing(15, 1000, BestX, BestValue),
    integer(BestX),
    BestX >= 0,
    BestX =< 20,
    BestValue >= 12.
test(zero_steps_returns_initial_state) :-
    user:simulated_annealing(15, 0, 15, 12).
:- end_tests(practical_10_simulated_annealing).

:- begin_tests(practical_11_map_coloring_csp).
test(all_regions_assigned) :-
    user:map_coloring(Assignment),
    length(Assignment, 7).
test(adjacent_regions_have_different_colors) :-
    user:map_coloring(Assignment),
    forall(user:map_adjacent(Region1, Region2),
           ( memberchk(Region1-Color1, Assignment),
             memberchk(Region2-Color2, Assignment),
             Color1 \= Color2 )).
:- end_tests(practical_11_map_coloring_csp).

:- begin_tests(practical_12_n_queens).
test(four_queens_has_two_solutions) :-
    findall(Positions, user:n_queens(4, Positions), Solutions),
    sort(Solutions, UniqueSolutions),
    length(UniqueSolutions, 2).
test(two_queens_has_no_solution, [fail]) :- user:n_queens(2, _).
:- end_tests(practical_12_n_queens).

main :-
    run_tests,
    halt.

:- initialization(main, main).
